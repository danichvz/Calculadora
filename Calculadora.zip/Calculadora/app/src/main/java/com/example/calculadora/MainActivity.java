package com.example.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    Button _btnEmpezar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        _btnEmpezar = findViewById(R.id.btnEmpezar);
        _btnEmpezar.setOnClickListener(new View.OnClickListener(){
                @Override
                        public void onClick(View v) {
            startActivity(new Intent(getApplicationContext(),Calcular.class));
            finish();
        }
    });
}